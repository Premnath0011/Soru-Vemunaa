import React from 'react';import{Outlet}from'react-router-dom';import BottomNav from'../components/BottomNav';
export default function MainLayout(){return <div className="app-shell"><main className="phone-shell"><Outlet/></main><BottomNav/></div>}
