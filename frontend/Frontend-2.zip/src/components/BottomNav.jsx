import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  FiHome,
  FiFolder,
  FiCreditCard,
//   FiLightbulb,
  FiMoreHorizontal,
  FiPlus,
} from "react-icons/fi";
export default function BottomNav() {
  const nav = useNavigate();
  const items = [
    ["/", "Home", FiHome],
    ["/projects", "Projects", FiFolder],
    ["/money", "Money", FiCreditCard],
    ["/ideas", "Ideas", FiCreditCard],
    ["/more", "More", FiMoreHorizontal],
  ];
  return (
    <div className="bottom-nav">
      {items.slice(0, 2).map(([to, label, I]) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
        >
          <I />
          <span>{label}</span>
        </NavLink>
      ))}
      <button className="nav-add" onClick={() => nav("/money?add=1")}>
        <FiPlus />
      </button>
      {items.slice(2).map(([to, label, I]) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
        >
          <I />
          <span>{label}</span>
        </NavLink>
      ))}
    </div>
  );
}
